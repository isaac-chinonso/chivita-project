<?php if(Session::has('Success_message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong></strong> <?php echo e(Session::get('Success_message')); ?>

</div>
<?php endif; ?><?php /**PATH C:\laragon\www\chivita project\resources\views/include/success.blade.php ENDPATH**/ ?>