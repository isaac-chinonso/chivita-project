
<?php $__env->startSection('title'); ?>
Profile || Chivita
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="services-area sec-mar" style="padding-top: 100px;">
    <div class="container">
        <div class="wow animate fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">
            <div class="sec-title">
                <h2 class="text-center">My <b class="text-danger">Profile</b></h2>
                <p><?php echo e(Auth::user()->profile->first()->fname); ?> <?php echo e(Auth::user()->profile->first()->lname); ?></p>
            </div>
        </div><br><br>
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('include.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.warning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('include.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="tabs">
                    <div class="tabby-tab">
                        <input type="radio" id="tab-1" name="tabby-tabs" checked>
                        <label for="tab-1">Profile Info</label>
                        <div class="tabby-content">
                            <form method="post" action="">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="text-left">First Name</label>
                                            <input type="text" class="form-control" name="fname" value="<?php echo e(Auth::user()->profile->first()->fname); ?>" disabled>
                                        </div><br>
                                        <div class="col-md-6">
                                            <label class="text-left">Last Name</label>
                                            <input type="text" class="form-control" name="lname" value="<?php echo e(Auth::user()->profile->first()->lname); ?>" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-left">Email Address</label>
                                            <input type="email" class="form-control" name="fname" value="<?php echo e(Auth::user()->email); ?>" disabled>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="text-left">Phone Number</label>
                                            <input type="phone" class="form-control" name="phone" value="<?php echo e(Auth::user()->profile->first()->phone); ?>" disabled>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="text-left">Social Media Handle</label>
                                            <input type="text" class="form-control" name="instagram" value="<?php echo e(Auth::user()->profile->first()->instagram); ?>">
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-danger btn-lg btn-block">Update Profile</button>
                            </form>
                        </div>
                    </div>

                    <div class="tabby-tab">
                        <input type="radio" id="tab-2" name="tabby-tabs">
                        <label for="tab-2">My Videos</label>
                        <div class="tabby-content">
                            <div class="line">
                                <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="media" style="padding: 20px;">

                                    <video width="180" height="126" controls>
                                        <source src="../upload/<?php echo e($vid->source); ?>" type="video/mp4">
                                        <source src="../upload/<?php echo e($vid->source); ?>" type="video/ogg ">
                                        Your browser does not support the video tag.
                                    </video>

                                    <div class="media-body" style="padding: 15px 20px 15px 20px;">
                                        <h5 class="mt-0 ">My Chivita Moments</h5>
                                        <small class="text-muted"><?php echo e($vid->created_at->diffForHumans()); ?></small><br><br>
                                        <form method="post" action="<?php echo e(url('/user/save-videos-ikes')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="video_id" value="<?php echo e($vid->id); ?>">
                                            <button type="submit" class="btn btn-outline-dark btn-sm" style="border: #fff solid 1px"><i class="fa fa-thumbs-up "></i> Like</button> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo e($countvideolikes); ?> Likes
                                        </form>
                                    </div>
                                    <div class="dropDown">
                                        <i class="fa fa-ellipsis-h"></i> 
                                        <div class="submenu">
                                            <a href="#" class="copy-btn" data-url="<?php echo e(asset('upload/' . $vid->source)); ?>"><i class="fa fa-copy"></i> Copy</a>
                                            
                                            <a href="#"><i class="fa fa-share"></i> Share</a>
                                            
                                            <a href="<?php echo e(route('deletevideo', $vid->id)); ?>" class="text-danger"><i class="fa fa-trash"></i> Delete</a>
                                            
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><br><br>

                            <form method="post" action="<?php echo e(route('savevideo')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <label class="text-left">Upload your 15 Seconds Video</label>
                                <input type="file" name="image" class="form-control" value="250000" required><br>
                                <button type="submit" class="btn bot btn-lg btn-block">Upload New Video</button>
                            </form>
                        </div>
                    </div>

                    <div class="tabby-tab">
                        <input type="radio" id="tab-3" name="tabby-tabs">
                        <label for="tab-3">Change Password</label>
                        <div class="tabby-content">
                            <form method="post" action="<?php echo e(route('user.update-password')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6 col-lg-12">
                                            <label class="text-left">Enter Old Password</label>
                                            <input type="password" class="form-control" name="current_password">
                                        </div>
                                        <div class="col-md-6 col-lg-6">
                                            <label class="text-left">Enter New Password</label>
                                            <input type="password" class="form-control" name="password">
                                        </div>
                                        <div class="col-md-6 col-lg-6">
                                            <label class="text-left">Confirm New Password</label>
                                            <input type="password" class="form-control" name="password_confirmation">
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-danger btn-lg btn-block">Save</button>
                            </form><br>
                        </div>
                    </div>
                </div>

            </div>
        </div>
</section>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('.copy-btn').click(function() {
            var url = $(this).data('url');
            
            navigator.clipboard.writeText(url)
                .then(function() {
                    alert('URL copied to clipboard!');
                })
                .catch(function() {
                    alert('Unable to copy URL to clipboard.');
                });
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\chivita project\resources\views/frontend/profile.blade.php ENDPATH**/ ?>